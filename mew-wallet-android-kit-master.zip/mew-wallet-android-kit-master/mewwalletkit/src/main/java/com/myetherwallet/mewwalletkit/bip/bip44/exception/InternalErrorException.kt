package com.myetherwallet.mewwalletkit.bip.bip44.exception

/**
 * Created by BArtWell on 13.06.2019.
 */

class InternalErrorException : Exception()