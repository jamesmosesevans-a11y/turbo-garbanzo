package com.myetherwallet.mewwalletkit.eip.eip155.exception

/**
 * Created by BArtWell on 14.06.2019.
 */

class InvalidPublicKeyException : Exception()