package com.myetherwallet.mewwalletkit.bip.bip39.exception

/**
 * Created by BArtWell on 21.05.2019.
 */

class InvalidMnemonicException : Exception()