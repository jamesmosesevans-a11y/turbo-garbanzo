package com.myetherwallet.mewwalletkit.bip.bip39.exception

import java.lang.Exception

/**
 * Created by BArtWell on 22.05.2019.
 */

class InvalidBitsOfEntropyException :  Exception()