package com.myetherwallet.mewwalletkit.bip.bip44.exception

/**
 * Created by BArtWell on 07.06.2019.
 */

class InvalidDataException : Exception()