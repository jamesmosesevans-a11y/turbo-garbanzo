package com.myetherwallet.mewwalletkit.bip.bip39.wordlist

/**
 * Created by BArtWell on 16.05.2019.
 */

interface BaseWordlist {

    val words: Array<String>
}