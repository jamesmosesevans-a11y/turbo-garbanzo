package com.myetherwallet.mewwalletkit.bip.bip39.exception

/**
 * Created by BArtWell on 22.05.2019.
 */

class NoEntropyException : Exception()