package com.myetherwallet.mewwalletkit.eip.eip681

/**
 * Created by BArtWell on 15.09.2021.
 */

enum class EipQrCodeType {
    PAY
}
