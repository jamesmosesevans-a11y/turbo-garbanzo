package com.myetherwallet.mewwalletkit.bip.bip39.wordlist

/**
 * Created by BArtWell on 17.05.2019.
 */

class CustomWordlist(override val words: Array<String>) : BaseWordlist
